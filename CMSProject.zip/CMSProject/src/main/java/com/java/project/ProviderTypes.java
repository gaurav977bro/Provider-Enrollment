package com.java.project;

public enum ProviderTypes {

	Pediatrician,
	Gynecologists,
	Child_Psychologist_or_Psychiatrist,
	Dermatologist,
	Cardiologist ,
	Ear_Nose_and_Throat_Specialist,
	Veterinarian ,
	Neurologist ,
	Therapist ,
	Psychologist,
	Audiologist,
	Dentist ,
	Allergist,
	Endocrinologist; 
}

