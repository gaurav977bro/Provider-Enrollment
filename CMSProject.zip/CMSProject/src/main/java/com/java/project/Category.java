package com.java.project;

public enum Category {
	
	PUBLIC , GOVERNMENT, PRIVATE;
}
