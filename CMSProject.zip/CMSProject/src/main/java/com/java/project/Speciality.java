package com.java.project;

public enum Speciality {

	UNANI, ALLOPATHY, DENTAL, AYURVEDA, YOGA, NATUROPATHY, SIDDHA, HOMEOPATHY, SOWA_RIGPA;
														
}
