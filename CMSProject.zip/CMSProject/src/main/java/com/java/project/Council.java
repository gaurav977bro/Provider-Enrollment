package com.java.project;

public enum Council {
	State_Medical_Councils,
	Medical_Council_of_India,
	Dental_Council_of_India,
	Central_Council_of_Indian_Medicine,
	Central_Council_of_Homeopathy;
	
}
