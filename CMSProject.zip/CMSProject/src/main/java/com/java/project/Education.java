package com.java.project;

public enum Education {
	
	MBBS, BYNS, BHMS, BDS, BAMS, BUMS, BVScAH;

}


