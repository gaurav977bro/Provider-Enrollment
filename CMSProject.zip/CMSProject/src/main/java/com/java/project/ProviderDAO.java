package com.java.project;

import java.util.List;

public interface ProviderDAO {

	String addProvider(Provider provider);
	List<Provider> showProvider();
}
