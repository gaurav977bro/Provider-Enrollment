package com.java.project;

public enum Questions {

	First_School, Favourite_Sport, Father_Birthday, First_Car, College_Name, Native_city, Nickname;
}
