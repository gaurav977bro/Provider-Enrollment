package com.java.project;

public enum Questions2 {
	First_Car, College_Name, First_School, Favourite_Sport, Father_Birthday, Native_city, Nickname;

}
