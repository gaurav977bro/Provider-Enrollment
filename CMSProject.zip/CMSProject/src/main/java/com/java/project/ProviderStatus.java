package com.java.project;

public enum ProviderStatus {
	
	ACTIVE, PENDING, SUSPENDED;

}
